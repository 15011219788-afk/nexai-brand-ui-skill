// 由 v1.3/build/generate.mjs 从 tokens.json 生成，请勿手改。
// 奈势AI（NexAI）Astryx 主题 v1.3.2 · 2026-11-12 · 对齐 meta/astryx@4705e676（2026-11-12 clone）

export {nexaiTheme} from './nexaiTheme';
export {nexaiPalette} from './nexaiPalette.generated';

// 由 v1.3/build/generate.mjs 从 tokens.json 生成，请勿手改。
// 奈势AI（NexAI）Astryx 主题 v1.3.2 · 2026-11-12 · 对齐 meta/astryx@4705e676（2026-11-12 clone）

import {defineTheme, type TokenValue} from '@astryxdesign/core/theme';

/**
 * Astryx 可移植 token（179 个，覆盖核心 211 个中的 179 个）。
 * 字符串 = 两种模式同值；[浅, 深] 元组 = 编译成 CSS light-dark()。
 * 没写的 32 个（8 族多色分类色）按 Xiangjun 2026-11-12 的决定继承 Astryx 默认值。
 */
const tokens: Record<string, TokenValue> = {
  // ── 背景 ──
  '--color-background-body': ["#F6F6F8", "#262626"], // nx-surface / nx-ink · 页面底（最底层）
  '--color-background-surface': ["#FFFFFF", "#262626"], // nx-white / nx-ink · 主画布、导航、与页面同层的大面板
  '--color-background-card': ["#FFFFFF", "#313030"], // nx-white / nx-neutral-dk-20 · 卡片、列表容器（比页面高一层）
  '--color-background-popover': ["#FFFFFF", "#3D3C3C"], // nx-white / nx-neutral-dk-25 · 菜单、弹窗、浮层（最高层）
  '--color-background-muted': ["#F6F6F8", "#1B1B1B"], // nx-surface / nx-neutral-dk-10 · 卡片内的次级分区、代码块、输入框静止底
  '--color-background-inverted': ["#262626", "#F6F6F8"], // nx-ink / nx-surface · 反相块（toast 等）
  '--color-background-error-inverted': "#B42318", // nx-danger / nx-danger · 反相面上的错误填充（错误 Toast 底）；浅/深都用 #B42318，配 #F6F6F8 字
  // ── 文字 ──
  '--color-text-primary': ["#262626", "#F6F6F8"], // nx-ink / nx-surface · 标题、正文
  '--color-text-secondary': ["#6E6E73", "#BDBDC1"], // nx-gray / nx-neutral-dk-75 · 说明、元信息
  '--color-text-disabled': ["#A2A2A7", "#7B7B7F"], // nx-neutral-65 / nx-neutral-dk-50 · 不可用文字（豁免对比度，须配合其他不可用提示）
  '--color-text-accent': ["#6857E7", "#BBBBFE"], // nx-purple / nx-lavender · 链接、品牌强调文字
  '--color-on-dark': "#FFFFFF", // nx-white / nx-white · 深色面（深紫块、墨黑块、图片）上的文字
  '--color-on-light': "#262626", // nx-ink / nx-ink · 浅色面（薰衣草、珊瑚橙、白图）上的文字
  // ── 图标 ──
  '--color-icon-primary': ["#262626", "#F6F6F8"], // nx-ink / nx-surface
  '--color-icon-secondary': ["#6E6E73", "#BDBDC1"], // nx-gray / nx-neutral-dk-75
  '--color-icon-disabled': ["#A2A2A7", "#7B7B7F"], // nx-neutral-65 / nx-neutral-dk-50
  '--color-icon-accent': ["#6857E7", "#BBBBFE"], // nx-purple / nx-lavender
  // ── 边框 ──
  '--color-border': ["#E8E8EB", "rgba(246, 246, 248, 0.10)"], // nx-neutral-90 · 分隔线、卡片描边（装饰性）
  '--color-border-emphasized': ["#87878C", "#949499"], // nx-neutral-55 / nx-neutral-dk-60 · 控件边界：输入框、复选框（≥3:1）
  // ── 主行动 ──
  '--color-accent': "#6857E7", // nx-purple / nx-purple · 主按钮、选中、开关；每个操作组只有一个
  '--color-on-accent': "#FFFFFF", // nx-white / nx-white
  '--color-accent-muted': ["#F1F0FD", "#3C237C"], // nx-mist / nx-purple-deep · 选中底、品牌标签底
  // ── 状态 ──
  '--color-success': ["#08755F", "#6EBDA6"], // nx-success / nx-success-dk-70 · success 强填充
  '--color-on-success': ["#FFFFFF", "#262626"], // nx-white / nx-ink
  '--color-success-muted': ["#D5FBEE", "#2C3F3A"], // nx-success-95 · 浅底
  '--color-on-success-muted': ["#035846", "#99D5C3"], // nx-success-30 / nx-success-dk-80
  '--color-text-success': ["#08755F", "#84C9B4"], // nx-success / nx-success-dk-75 · 页面/卡片上的状态文字
  '--color-icon-success': ["#08755F", "#84C9B4"], // nx-success / nx-success-dk-75
  '--color-border-success': ["#08755F", "#84C9B4"], // nx-success / nx-success-dk-75
  '--color-warning': ["#B45F06", "#E89454"], // nx-warning / nx-warning-dk-70 · warning 强填充
  '--color-on-warning': ["#FFFFFF", "#262626"], // nx-white / nx-ink
  '--color-warning-muted': ["#FFEDE1", "#483628"], // nx-warning-95 · 浅底
  '--color-on-warning-muted': ["#773701", "#FFB37C"], // nx-warning-30 / nx-warning-dk-80
  '--color-text-warning': ["#A15204", "#F4A468"], // nx-warning-40 / nx-warning-dk-75 · 页面/卡片上的状态文字
  '--color-icon-warning': ["#A15204", "#F4A468"], // nx-warning-40 / nx-warning-dk-75
  '--color-border-warning': ["#A15204", "#F4A468"], // nx-warning-40 / nx-warning-dk-75
  '--color-error': ["#B42318", "#E8705F"], // nx-danger · error 强填充（危险按钮底）；深色为 #E8705F，配墨黑字
  '--color-on-error': ["#FFFFFF", "#262626"], // nx-white / nx-ink
  '--color-error-muted': ["#FFECE8", "#4B3330"], // nx-error-95 · 浅底
  '--color-on-error-muted': ["#8F0201", "#FFAFA2"], // nx-error-30 / nx-error-dk-80
  '--color-text-error': ["#B42318", "#F78676"], // nx-danger / nx-error-dk-70 · 页面/卡片上的状态文字
  '--color-icon-error': ["#B42318", "#F78676"], // nx-danger / nx-error-dk-70
  '--color-border-error': ["#B42318", "#FF9989"], // nx-danger / nx-error-dk-75
  '--color-info': "#6857E7", // nx-purple / nx-purple · 信息态复用奈势紫（单色相品牌），必须带图标
  '--color-on-info': "#FFFFFF", // nx-white / nx-white
  '--color-info-muted': ["#F1F0FD", "#3C237C"], // nx-mist / nx-purple-deep
  '--color-on-info-muted': ["#3C237C", "#BBBBFE"], // nx-purple-deep / nx-lavender
  '--color-text-info': ["#6857E7", "#BBBBFE"], // nx-purple / nx-lavender
  '--color-icon-info': ["#6857E7", "#BBBBFE"], // nx-purple / nx-lavender
  '--color-border-info': ["#6857E7", "#BBBBFE"], // nx-purple / nx-lavender
  // ── 交互 ──
  '--color-neutral': ["rgba(38, 38, 38, 0.06)", "rgba(246, 246, 248, 0.12)"], // — · 中性浅填充（次按钮底、中性标签底）
  '--color-overlay': ["rgba(38, 38, 38, 0.40)", "rgba(0, 0, 0, 0.56)"], // — · 弹窗遮罩
  '--color-overlay-hover': ["rgba(38, 38, 38, 0.05)", "rgba(246, 246, 248, 0.06)"], // — · 悬停叠加（叠在原底上，不替换）
  '--color-overlay-pressed': ["rgba(38, 38, 38, 0.09)", "rgba(246, 246, 248, 0.10)"], // — · 按下叠加
  '--color-tint-hover': ["#262626", "#F6F6F8"], // nx-ink / nx-surface · color-mix 用的悬停基色（Astryx 约定：浅色深、深色浅）
  '--color-shadow': ["rgba(60, 35, 124, 0.10)", "rgba(0, 0, 0, 0.30)"], // — · 阴影色（深紫调）
  '--color-skeleton': ["#E8E8EB", "#3D3C3C"], // nx-neutral-90 / nx-neutral-dk-25 · 骨架屏
  '--color-track': ["#E8E8EB", "#3D3C3C"], // nx-neutral-90 / nx-neutral-dk-25 · 进度条/滑轨底
  // ── 分类色 ──
  '--color-background-purple': ["#F1F0FD", "#3C237C"], // nx-mist / nx-purple-deep · 分类色·紫 = 品牌紫
  '--color-background-gray': ["#E8E8EB", "#3D3C3C"], // nx-neutral-90 / nx-neutral-dk-25 · 分类色·灰 = 中性灰
  '--color-border-purple': ["#BBBBFE", "#5743B7"], // nx-lavender / nx-purple-35 · 分类色·紫 = 品牌紫
  '--color-border-gray': ["#CCCCCF", "#575457"], // nx-neutral-80 / nx-neutral-dk-35 · 分类色·灰 = 中性灰
  '--color-icon-purple': ["#6857E7", "#BBBBFE"], // nx-purple / nx-lavender · 分类色·紫 = 品牌紫
  '--color-icon-gray': ["#6E6E73", "#BDBDC1"], // nx-gray / nx-neutral-dk-75 · 分类色·灰 = 中性灰
  '--color-text-purple': ["#6857E7", "#BBBBFE"], // nx-purple / nx-lavender · 分类色·紫 = 品牌紫
  '--color-text-gray': ["#6E6E73", "#BDBDC1"], // nx-gray / nx-neutral-dk-75 · 分类色·灰 = 中性灰
  // ── font-family ──
  '--font-family-body': "MiSans, 'PingFang SC', 'Microsoft YaHei', sans-serif", // 品牌字体 MiSans
  '--font-family-heading': "var(--font-family-body)",
  '--font-family-code': "\"JetBrains Mono\", \"SF Mono\", Menlo, Consolas, monospace", // 仅代码
  // ── font-weight ──
  '--font-weight-normal': "400", // 正文
  '--font-weight-medium': "500", // 标签、按钮
  '--font-weight-semibold': "600", // 标题（v1.3 标题默认字重）
  '--font-weight-bold': "700", // 只用于视频字幕、社媒封面等远看场景
  // ── font-size ──
  '--font-size-2xs': "0.625rem", // 仅英文微标，中文最小 12px
  '--font-size-xs': "0.75rem",
  '--font-size-sm': "0.875rem",
  '--font-size-base': "1rem", // 正文基准
  '--font-size-lg': "1.25rem",
  '--font-size-xl': "1.5rem",
  '--font-size-2xl': "1.875rem",
  '--font-size-3xl': "2.375rem",
  '--font-size-4xl': "3rem",
  '--font-size-5xl': "3.75rem",
  '--font-size-3xs': "var(--font-size-2xs)", // 奈势不用；兼容 Astryx 档位
  '--font-size-4xs': "var(--font-size-2xs)", // 奈势不用；兼容 Astryx 档位
  // ── text ──
  '--text-display-1-size': "var(--font-size-5xl)", // 首屏大标题（桌面；移动端用 3xl）
  '--text-display-1-weight': "var(--font-weight-semibold)",
  '--text-display-1-leading': "1.1",
  '--text-display-2-size': "var(--font-size-4xl)", // 区块大标题、封面
  '--text-display-2-weight': "var(--font-weight-semibold)",
  '--text-display-2-leading': "1.15",
  '--text-display-3-size': "var(--font-size-3xl)", // 大数字、引语
  '--text-display-3-weight': "var(--font-weight-semibold)",
  '--text-display-3-leading': "1.2",
  '--text-heading-1-size': "var(--font-size-3xl)", // 页面标题
  '--text-heading-1-weight': "var(--font-weight-semibold)",
  '--text-heading-1-leading': "1.2",
  '--text-heading-2-size': "var(--font-size-2xl)", // 一级区块标题
  '--text-heading-2-weight': "var(--font-weight-semibold)",
  '--text-heading-2-leading': "1.3",
  '--text-heading-3-size': "var(--font-size-xl)", // 卡片标题、二级标题
  '--text-heading-3-weight': "var(--font-weight-semibold)",
  '--text-heading-3-leading': "1.35",
  '--text-heading-4-size': "var(--font-size-lg)", // 小节标题
  '--text-heading-4-weight': "var(--font-weight-semibold)",
  '--text-heading-4-leading': "1.4",
  '--text-heading-5-size': "var(--font-size-base)", // 列表组标题
  '--text-heading-5-weight': "var(--font-weight-semibold)",
  '--text-heading-5-leading': "1.5",
  '--text-heading-6-size': "var(--font-size-sm)", // 表头、分组小标题
  '--text-heading-6-weight': "var(--font-weight-semibold)",
  '--text-heading-6-leading': "1.5",
  '--text-large-size': "1.125rem", // 导语、引言
  '--text-large-weight': "var(--font-weight-normal)",
  '--text-large-leading': "1.7",
  '--text-body-size': "var(--font-size-base)", // 正文（中文段落）
  '--text-body-weight': "var(--font-weight-normal)",
  '--text-body-leading': "1.75",
  '--text-label-size': "var(--font-size-sm)", // 按钮、表单标签、导航
  '--text-label-weight': "var(--font-weight-medium)",
  '--text-label-leading': "1.4",
  '--text-supporting-size': "var(--font-size-xs)", // 注释、来源、时间戳
  '--text-supporting-weight': "var(--font-weight-normal)",
  '--text-supporting-leading': "1.5",
  '--text-code-size': "var(--font-size-sm)", // 代码
  '--text-code-weight': "var(--font-weight-normal)",
  '--text-code-leading': "1.6",
  // ── spacing ──
  '--spacing-0': "0rem",
  '--spacing-0-5': "0.125rem",
  '--spacing-1': "0.25rem",
  '--spacing-1-5': "0.375rem",
  '--spacing-2': "0.5rem",
  '--spacing-3': "0.75rem",
  '--spacing-4': "1rem",
  '--spacing-5': "1.25rem",
  '--spacing-6': "1.5rem",
  '--spacing-7': "1.75rem",
  '--spacing-8': "2rem",
  '--spacing-9': "2.25rem",
  '--spacing-10': "2.5rem",
  '--spacing-11': "2.75rem",
  '--spacing-12': "3rem",
  // ── size ──
  '--size-element-sm': "32px", // 紧凑控件
  '--size-element-md': "40px", // 默认按钮/输入框
  '--size-element-lg': "48px", // 营销页大按钮、移动端
  // ── border ──
  '--border-width': "1px",
  // ── focus ──
  '--focus-outline-width': "2px",
  '--focus-outline-style': "solid",
  '--focus-outline-color': "var(--nx-color-border-accent)", // 浅色奈势紫 / 深色薰衣草
  '--focus-outline-offset': "2px",
  // ── radius ──
  '--radius-none': "0px",
  '--radius-inner': "0.375rem", // 6px · 嵌套在控件/卡片里的元素、代码片段
  '--radius-element': "0.625rem", // 10px · 按钮、输入框、下拉、小图
  '--radius-container': "1rem", // 16px · 卡片、弹窗、提示条、菜单
  '--radius-page': "1.75rem", // 28px · Hero、特性大面板、封面卡
  '--radius-chat': "var(--radius-page)", // 对话气泡容器，同 page
  '--radius-full': "9999px", // 胶囊：标签、头像、开关
  // ── shadow ──
  '--shadow-low': ["0 1px 2px rgba(38, 38, 38, 0.04), 0 2px 8px rgba(60, 35, 124, 0.05)", "0 1px 2px rgba(0, 0, 0, 0.30), 0 2px 8px rgba(0, 0, 0, 0.30), inset 0 0 0 1px rgba(246, 246, 248, 0.06)"], // 悬停抬起的卡片、吸顶栏
  '--shadow-med': ["0 2px 4px rgba(38, 38, 38, 0.04), 0 8px 20px rgba(60, 35, 124, 0.07)", "0 2px 4px rgba(0, 0, 0, 0.35), 0 8px 20px rgba(0, 0, 0, 0.45), inset 0 0 0 1px rgba(246, 246, 248, 0.08)"], // 下拉菜单、气泡、浮动工具条
  '--shadow-high': ["0 4px 8px rgba(38, 38, 38, 0.05), 0 16px 40px rgba(60, 35, 124, 0.10)", "0 4px 8px rgba(0, 0, 0, 0.45), 0 16px 40px rgba(0, 0, 0, 0.60), inset 0 0 0 1px rgba(246, 246, 248, 0.10)"], // 弹窗、抽屉（最高层）
  '--shadow-inset-hover': ["inset 0 0 0 2px rgba(38, 38, 38, 0.15)", "inset 0 0 0 2px rgba(246, 246, 248, 0.20)"], // 输入框状态环（不是层级阴影）
  '--shadow-inset-selected': ["inset 0 0 0 2px rgba(104, 87, 231, 0.50)", "inset 0 0 0 2px rgba(187, 187, 254, 0.50)"], // 输入框状态环（不是层级阴影）
  '--shadow-inset-success': ["inset 0 0 0 2px rgba(8, 117, 95, 0.30)", "inset 0 0 0 2px rgba(110, 189, 166, 0.30)"], // 输入框状态环（不是层级阴影）
  '--shadow-inset-warning': ["inset 0 0 0 2px rgba(180, 95, 6, 0.30)", "inset 0 0 0 2px rgba(244, 164, 104, 0.30)"], // 输入框状态环（不是层级阴影）
  '--shadow-inset-error': ["inset 0 0 0 2px rgba(180, 35, 24, 0.30)", "inset 0 0 0 2px rgba(247, 134, 118, 0.30)"], // 输入框状态环（不是层级阴影）
  // ── duration ──
  '--duration-fast-min': "95ms",
  '--duration-fast': "125ms", // 悬停、按下、开关、颜色变化
  '--duration-fast-max': "165ms",
  '--duration-medium-min': "225ms",
  '--duration-medium': "300ms", // 浮层进出、展开收起
  '--duration-medium-max': "400ms",
  '--duration-slow-min': "525ms",
  '--duration-slow': "700ms", // 大面积转场、首屏入场（每页至多一处）
  '--duration-slow-max': "935ms",
  '--duration-exit': "var(--duration-fast)", // 退出比进入快
  // ── ease ──
  '--ease-standard': "cubic-bezier(0.24, 1, 0.4, 1)", // 默认减速：到达与状态变化
  '--ease-entrance': "cubic-bezier(0.24, 1, 0.4, 1)", // 入场（不回弹）
  '--ease-move': "cubic-bezier(0.24, 1, 0.4, 1)", // 位移、尺寸变化
  '--ease-exit': "cubic-bezier(0.3, 0, 0.6, 0.6)", // 离场：从静止加速离开
};

/**
 * 奈势本地 token（Astryx 没有的角色）。名字保持与 tokens.css 一致（--nx-*），
 * 组件和页面可以直接 var(--nx-color-accent-hover) 使用。
 */
const localTokens: Record<string, TokenValue> = {
  '--nx-color-background-brand': ["#F1F0FD", "#3C237C"], // nx-mist / nx-purple-deep · 品牌浅底面板（雾紫；深色下为深紫）
  '--nx-color-background-emphasized': "#3C237C", // nx-purple-deep / nx-purple-deep · 深紫强调色块：封面、Hero、数据大字块
  '--nx-color-on-emphasized-secondary': "#BBBBFE", // nx-lavender / nx-lavender · 深紫色块上的副标题/强调字
  '--nx-color-text-highlight': "#FF604A", // nx-coral / nx-coral · 珊瑚橙字：浅色下仅装饰（<3:1），深色下可作大字；每版一处
  '--nx-color-border-accent': ["#6857E7", "#BBBBFE"], // nx-purple / nx-lavender · 选中描边；深色下的纯图形选中态
  '--nx-color-on-accent-muted': ["#3C237C", "#BBBBFE"], // nx-purple-deep / nx-lavender · 选中底上的文字
  '--nx-color-accent-hover': "#5F4AD4", // nx-purple-40 / nx-purple-dk-40 · 主行动悬停（Astryx 用 overlay 叠加实现，见映射表）
  '--nx-color-accent-pressed': ["#5743B7", "#5742B8"], // nx-purple-35 / nx-purple-dk-35 · 主行动按下
  '--nx-color-accent-muted-hover': ["#E0DFFD", "#462D8F"], // nx-purple-90 / nx-purple-dk-25 · 浅底悬停
  '--nx-color-highlight': "#FF604A", // nx-coral / nx-coral · 珊瑚橙填充：截止、限时、增长；每版一处
  '--nx-color-on-highlight': "#262626", // nx-ink / nx-ink · 珊瑚橙上的文字：必须墨黑（白字仅 2.99:1）
  '--nx-color-highlight-pressed': ["#EF4F3B", "#ED523C"], // nx-coral-55 / nx-coral-dk-55
  '--nx-color-button-danger': "#FF604A", // nx-coral / nx-coral · 破坏性/强调按钮填充：奈势标准珊瑚橙 #FF604A。白字仅 2.99:1，必须配墨黑字（5.06:1）。不改全局 --color-error，以免影响 Toast 与状态色。浅色与深色相同。
  '--nx-color-on-button-danger': "#262626", // nx-ink / nx-ink · 危险按钮上的文字与图标：品牌墨黑 #262626。浅色与深色均 5.06:1。
  '--nx-color-button-danger-hover': "#FA5B46", // — · 危险按钮悬停：沿珊瑚色阶 60→55 加深到 #FA5B46。下一档 coral-55 #EF4F3B 配墨黑仅 4.22:1，不采用；本色配墨黑 4.80:1。浅色与深色相同。
  '--nx-color-button-danger-pressed': "#F75742", // — · 危险按钮按下：沿珊瑚色阶 60→55 再深到 #F75742，配墨黑 4.60:1。浅色与深色相同。
  '--nx-color-highlight-muted': ["#FFECE8", "#4D302C"], // nx-coral-95 · 珊瑚橙浅底提示条
  '--nx-color-on-highlight-muted': ["#262626", "#F6F6F8"], // nx-ink / nx-surface · 珊瑚浅底上的文字（配珊瑚圆点）
  '--nx-color-tint-brand-hover': ["rgba(104, 87, 231, 0.08)", "rgba(187, 187, 254, 0.10)"], // — · 品牌色悬停叠加（列表项、幽灵按钮）
  '--nx-text-display-1-tracking': "-0.02em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-display-2-tracking': "-0.015em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-display-3-tracking': "-0.01em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-heading-1-tracking': "-0.01em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-heading-2-tracking': "-0.005em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-heading-3-tracking': "0em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-heading-4-tracking': "0em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-heading-5-tracking': "0em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-heading-6-tracking': "0em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-large-tracking': "0em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-body-tracking': "0em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-label-tracking': "0.01em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-supporting-tracking': "0.01em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-code-tracking': "0em", // 字距（奈势本地；Astryx 无此 token）
  '--nx-text-body-sm-size': "var(--font-size-sm)", // 紧凑正文、表格（奈势本地）
  '--nx-measure': "36em", // 中文段落行宽上限 ≈ 36 字
  '--nx-spacing-16': "4rem", // 奈势本地：区块级大间距
  '--nx-spacing-20': "5rem", // 奈势本地：区块级大间距
  '--nx-spacing-24': "6rem", // 奈势本地：区块级大间距
  '--nx-space-tight': "var(--spacing-2)", // 8px · 标签与字段、图标与文字
  '--nx-space-related': "var(--spacing-4)", // 16px · 同组元素之间
  '--nx-space-group': "var(--spacing-8)", // 32px · 组与组之间
  '--nx-space-section': "var(--nx-spacing-24)", // 96px · 页面区块之间（移动端 spacing-16 = 64px）
  '--nx-space-card': "var(--spacing-8)", // 32px · 卡片内边距（紧凑卡片 spacing-6）
  '--nx-space-control-x': "var(--spacing-4)", // 16px · 按钮/输入框水平内边距
  '--nx-page-max': "1240px",
  '--nx-sidebar': "176px",
  '--nx-sidebar-compact': "64px",
};

export const nexaiTheme = defineTheme({
  name: 'nexai',
  localTokens,
  typography: {
    body: {family: "MiSans", fallbacks: "'PingFang SC', 'Microsoft YaHei', sans-serif"},
    heading: {family: "MiSans", fallbacks: "'PingFang SC', 'Microsoft YaHei', sans-serif", weight: 'semibold'},
    code: {family: "JetBrains Mono", fallbacks: "\"SF Mono\", Menlo, Consolas, monospace"},
  },
  motion: {fast: 125, medium: 300, slow: 700, ratio: 0.75, character: 'standard'},
  tokens,
  components: {
    // 主按钮悬停/按下：Astryx 默认在 --color-accent 上叠 overlay；奈势定稿用实色
    // purple-40 #5F4AD4（悬停）/ purple-35 #5743B7（按下）。在主按钮作用域里把 overlay 置透明，
    // 再换底色，这样不会出现「实色 + 叠加」两层。禁用态保持 Astryx 原有处理。
    button: {
      'variant:primary': {
        '--color-overlay-hover': 'transparent',
        '--color-overlay-pressed': 'transparent',
        ':hover:not(:disabled, [aria-disabled="true"])': {
          backgroundColor: 'var(--nx-color-accent-hover)',
        },
        ':active:not(:disabled, [aria-disabled="true"])': {
          backgroundColor: 'var(--nx-color-accent-pressed)',
        },
      },
      // 危险/强调按钮：珊瑚橙 #FF604A + 墨黑字（5.06:1）。不改全局 --color-error，
      // 以免 Toast / 状态色跟着变。白字在珊瑚上仅 2.99:1，不能用。
      // 悬停/按下沿珊瑚 60→55 加深，但停在仍 ≥4.5 的位置（coral-55 + 墨黑仅 4.22）。
      // IconButton 是 Button 的薄封装，同一套覆写即可。禁用/加载保持 Astryx 默认（整钮 0.5 透明）。
      'variant:destructive': {
        backgroundColor: 'var(--nx-color-button-danger)',
        color: 'var(--nx-color-on-button-danger)',
        '--color-overlay-hover': 'transparent',
        '--color-overlay-pressed': 'transparent',
        ':hover:not(:disabled, [aria-disabled="true"])': {
          backgroundColor: 'var(--nx-color-button-danger-hover)',
          color: 'var(--nx-color-on-button-danger)',
        },
        ':active:not(:disabled, [aria-disabled="true"])': {
          backgroundColor: 'var(--nx-color-button-danger-pressed)',
          color: 'var(--nx-color-on-button-danger)',
        },
        ':focus-visible': {
          outlineColor: 'var(--nx-color-on-button-danger)',
        },
      },
    },
  },
});

# @nexai/theme-nexai · 奈势AI Astryx 主题包 v1.3.2

奈势AI（NexAI）品牌规范 v1.3 的 [Meta Astryx](https://github.com/meta/astryx) 主题。颜色、字体、间距、圆角、阴影、动效都来自 `tokens.json`（唯一数据源），和 brand.nexai.link 上的 `tokens.css` 是同一份数据。

- 对齐版本：`meta/astryx@4705e676`，`@astryxdesign/core` / `@astryxdesign/cli` **0.7.15**（Astryx 目前是 Beta，升级 Core 前先在这里重新构建、跑校验）。
- 需要 React 19（Astryx 的要求）。不用 React 的项目直接用包里的 `tokens.css`。
- 本包 `private: true`，不发布到 npm；用 tarball 安装。



## v1.3.2（2026-11-12）

- 危险/强调按钮改为奈势标准珊瑚橙 `#FF604A`，配品牌墨黑字 `#262626`（5.06:1）。白字在珊瑚上仅 2.99:1，不能用。
- 悬停 `#FA5B46`（墨黑 4.80:1）、按下 `#F75742`（墨黑 4.60:1）：沿珊瑚色阶 60→55 加深，但停在对比度仍 ≥4.5 的位置（下一档 coral-55 `#EF4F3B` 配墨黑仅 4.22:1）。浅色与深色相同。
- 通过主题包 `button['variant:destructive']` 覆写实现（IconButton 同款）。全局 `--color-error`、错误 Toast、深色错误文字/图标 `#F78676` 均不改动。禁用/加载保持 Astryx 默认（整钮 0.5 透明）。

## v1.3.1（2026-11-12）

- 深色错误 Toast 底由 `#DD6858` 改为 `#B42318`，配 `#F6F6F8` 字（6.09:1）。
- 深色危险按钮底由 `#F78676` 改为 `#E8705F`，配墨黑字（4.98:1）；`#F78676` 留给深色错误文字和图标。
## 安装

```bash
pnpm add ./nexai-theme-nexai-1.3.2.tgz @astryxdesign/core@0.7.15
```

## 使用（React + Astryx）

```tsx
import {Theme} from '@astryxdesign/core/theme';
import {nexaiTheme} from '@nexai/theme-nexai/built';   // 预构建版（推荐，SSR 不闪）
import '@nexai/theme-nexai/theme.css';

<Theme theme={nexaiTheme} mode="system">   {/* 'system' | 'light' | 'dark' */}
  <App />
</Theme>
```

开发时也可以用源码版 `import {nexaiTheme} from '@nexai/theme-nexai'`（运行时注入样式，不需要引 theme.css）。

**字体要自己加载。** Astryx 只设置 `--font-family-*`，不会下载字体。MiSans 从 https://hyperos.mi.com/font 下载后用 `@font-face` 自托管。

## 不用 React 的项目（网页、H5、小程序 WebView）

```html
<link rel="stylesheet" href="node_modules/@nexai/theme-nexai/tokens.css">
<html data-theme="dark">  <!-- 强制深色；不写则跟随系统；data-theme="light" 固定浅色 -->
```

变量名是 `--nx-*`。v1.2 的旧变量名全部保留为兼容别名。

## 命名规则

`--nx-X` 去掉 `nx-` 就是 Astryx 的 `--X`：`--nx-color-accent` ⇄ `--color-accent`。

| | 数量 | 在主题里的位置 |
|---|---|---|
| 对上 Astryx 核心 token | 179 / 211 | `tokens`，浅/深写成 `[浅, 深]` 元组，编译成 `light-dark()` |
| 没对上的 32 个分类色（蓝、青、绿、橙、粉、红、蓝绿、黄） | 32 | 不覆盖，继承 Astryx 默认值（Xiangjun 2026-11-12 决定） |
| 奈势本地 token（Astryx 没有） | 43 | `localTokens`，名字保持 `--nx-*`，例如 `--nx-color-accent-hover`、`--nx-color-highlight`、`--nx-space-section` |

逐项对照见 `astryx-mapping.md`（规范目录里）。

## 跟 Astryx 默认不一样的地方

- **主按钮悬停 / 按下**：Astryx 默认在主色上叠一层半透明 overlay。奈势用实色：悬停 `#5F4AD4`（purple-40），按下 `#5743B7`（purple-35）。主题在 `components.button['variant:primary']` 里把 overlay 置透明，再换底色；触屏按压同样生效，禁用态不变。
- **深色模式**：页面底是中性墨黑 `#262626`，卡片 `#313030`，浮层 `#3D3C3C`；主按钮仍是奈势紫配白字。
- **信息态 info 复用奈势紫**：有意偏离 Astryx「信息态独立于主色」的约定（奈势是单色相品牌），信息提示必须带图标。
- **字号**：16px 基准、约 1.25 比率（Astryx 默认 14px、1.2）；标题字重 600。
- **控件高度** 32 / 40 / 48px，**圆角** 6 / 10 / 16 / 28，**动效** 125 / 300 / 700ms。

## 包里有什么

| 路径 | 说明 |
|---|---|
| `dist/theme.css`、`dist/nexai.js`、`dist/nexai.d.ts` | `astryx theme build` 的产物（`./theme.css`、`./built`） |
| `dist/source.mjs` / `.cjs` | 源码版主题和色阶（`.`），导出 `nexaiTheme`、`nexaiPalette` |
| `src/` | 主题源码（由生成器写出，请勿手改） |
| `tokens.css` / `tokens.json` | 通用 CSS 变量 / 唯一数据源 |
| `palette.config.json` | Astryx 色阶生成器配置，`astryx theme palette generate` 可原样复现色阶 |

## 重新生成与校验

在规范目录 `v1.3/` 下：

```bash
node build/generate.mjs          # tokens.json → tokens.css、本包源码、安卓颜色
node build/generate.mjs --check  # 只比对，不写文件
bash build/astryx-build.sh       # 在 meta/astryx@4705e676 仓库里构建 + 校验 + 打包
```

`astryx-build.sh` 依次做这些事：`astryx theme build`、`--check` 防漂移、用 Astryx 色阶生成器复现色阶，再跑 10 项校验：179 个 token 浅/深两种模式解析值等于 tokens.json；本地 token 完整；32 个分类色继承默认值；主按钮悬停/按下实色；对比度按 Astryx INV11/INV12 阈值检查（正文、状态色 ≥ 4.5，图标/描边/控件边界 ≥ 3）。
